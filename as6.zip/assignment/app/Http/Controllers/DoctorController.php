<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Doctor;

/* New class DoctorController inherited from base controller class(controllers.php) in Laravel */
class DoctorController extends Controller
{

    /* Indexing method to retrieve all doctor records from database using ALL on Doctor model. Returns a view named doctors.index to the view. */
    public function index()
    {
        $doctors = Doctor::all();
        return view('doctors.index', ['doctors' => $doctors]);
    }

    /* Store method to create new Doctor instance, set properties. Save new request, Redirect user to app page */
    public function store(Request $request)
    {
        $doctor = new Doctor;
        $doctor->first_name = $request->first_name;
        $doctor->last_name = $request->last_name;
        $doctor->specialty = $request->specialty;
        $doctor->city = $request->city;
        $doctor->save();

        return redirect ('/app');
    }

    /* Destroy method deletes a doctor record from the database using delet method. Redirects user to app page */
    public function destroy(Doctor $doctor)
    {
        $doctor->delete();
        return redirect('/app');
    }
}
