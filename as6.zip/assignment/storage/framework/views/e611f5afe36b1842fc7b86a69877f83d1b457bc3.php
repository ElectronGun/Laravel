<!DOCTYPE html>
<html lang="en">
<head>
    <title>Doctor Records</title>
</head>
<body>
    <table>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Specialty</th>
            <th>City</th>
            <th>Delete</th>
        </tr>

        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($doctor->first_name); ?></td>
                <td><?php echo e($doctor->last_name); ?></td>
                <td><?php echo e($doctor->specialty); ?></td>
                <td><?php echo e($doctor->city); ?></td>
                <td>
                    <form action="<?php echo e(url('/app/' . $doctor->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">D</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    
    <form action="<?php echo e(url('/app')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="first_name" placeholder="First Name">
        <input type="text" name="last_name" placeholder="Last Name">
        <input type="text" name="specialty" placeholder="Specialty">
        <input type="text" name="city" placeholder="City">
        <button type="submit">Add Doctor</button>
    </form>
</body>
</html><?php /**PATH /home/laravel/Documents/assignment/resources/views/doctors/index.blade.php ENDPATH**/ ?>