<!DOCTYPE html>
<html lang="en">
<head>
    <title>Doctor Records</title>
</head>
<body>
    <table>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Specialty</th>
            <th>City</th>
            <th>Delete</th>
        </tr>

        @foreach ($doctors as $doctor)
            <tr>
                <td>{{ $doctor->first_name }}</td>
                <td>{{ $doctor->last_name }}</td>
                <td>{{ $doctor->specialty }}</td>
                <td>{{ $doctor->city }}</td>
                <td>
                    <form action="{{ url('/app/' . $doctor->id) }}" method="post">
                        @csrf
                        @method('DELETE')
                        <button type="submit">D</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
    
    <form action="{{ url('/app') }}" method="post">
        @csrf
        <input type="text" name="first_name" placeholder="First Name">
        <input type="text" name="last_name" placeholder="Last Name">
        <input type="text" name="specialty" placeholder="Specialty">
        <input type="text" name="city" placeholder="City">
        <button type="submit">Add Doctor</button>
    </form>
</body>
</html>